#include "remove_pointcloud/remove_pointcloud.hpp"
namespace taurus
{
    Remove_pointcloud::Remove_pointcloud(const rclcpp::NodeOptions &options) : Node("Remove_pointcloud",options)
    {
        tf_buffer_ = std::make_shared<tf2_ros::Buffer>(this->get_clock());
        transform_listener = std::make_shared<tf2_ros::TransformListener>(*tf_buffer_);
        livox_lidar_pointcloud.reset(new pcl::PointCloud<pcl::PointXYZ>);
        map_cloud_.reset(new pcl::PointCloud<pcl::PointXYZ>);

        transformed_cloud.reset(new pcl::PointCloud<pcl::PointXYZ>);
        if (!(rosInit() && paramInit()))
        {
            RCLCPP_ERROR(this->get_logger(), "Init Error");
            rclcpp::shutdown();
        }
        pcd_map_.header.frame_id = "map";
    }
    Remove_pointcloud::~Remove_pointcloud()
    {

    }
    bool Remove_pointcloud::rosInit(){
        using std::placeholders::_1;
        //发布者
        removed_cloud_pub_ = this->create_publisher<sensor_msgs::msg::PointCloud2>("removed_cloud_",10);
        map_pub            = this->create_publisher<sensor_msgs::msg::PointCloud2>("pcd_map",1); 
        map_frame_pointcloud_pub = this->create_publisher<sensor_msgs::msg::PointCloud2>("map_frame_pointcloud",1); 
        processed_point_cloud_pub_  = this->create_publisher<sensor_msgs::msg::PointCloud2>("processed_point_cloud_",1); 
        //订阅者
        livox_lidar_sub_   = this->create_subscription<sensor_msgs::msg::PointCloud2>("livox/lidar/pointcloud",rclcpp::QoS(rclcpp::KeepLast(1)),std::bind(&Remove_pointcloud::livox_lidar_sub_cbk_,  this, _1));
        return true;
    }
    bool Remove_pointcloud::paramInit(){
        return true;
    }
    bool Remove_pointcloud::pcdLoader(const std::string &filename){

        return true;
    }
    pcl::PointCloud<pcl::PointXYZ>::Ptr Remove_pointcloud::loadPointcloudFromPcd(const std::string &filename){
        pcl::PointCloud<pcl::PointXYZ>::Ptr cloud(new pcl::PointCloud<pcl::PointXYZ>);
        pcl::PCLPointCloud2 cloudBlob;
        pcl::io::loadPCDFile(filename, cloudBlob);
        pcl::fromPCLPointCloud2(cloudBlob, *cloud);
        pcl::toROSMsg(*cloud,pcd_map_);
        return cloud;
    }

    void Remove_pointcloud::livox_lidar_sub_cbk_(const sensor_msgs::msg::PointCloud2::SharedPtr msg)
    {
        pcl::fromROSMsg(*msg, *livox_lidar_pointcloud);
        if(is_first_frame_){
            pcd_map_.header.stamp = msg->header.stamp;
            map_pub->publish(pcd_map_);
            is_first_frame_ = false;
            map_cloud_ = loadPointcloudFromPcd(filename);
            kdTree.setInputCloud(map_cloud_);
        }
        //读取livox_frame到map的tf
        geometry_msgs::msg::TransformStamped tf_livox_to_map;
        try{
            tf_livox_to_map = tf_buffer_->lookupTransform("map", "livox_frame", tf2::TimePointZero);
        }catch(tf2::TransformException &ex){
            RCLCPP_ERROR(this->get_logger(), "Transform lookup failed: %s", ex.what());
            return; 
        }
        
        // 应用变换
        //将livox_lidar_pointcloud进行旋转，矩阵A*点云
        pcl_ros::transformPointCloud(*livox_lidar_pointcloud, *transformed_cloud, tf_livox_to_map);
        sensor_msgs::msg::PointCloud2 output;
        pcl::toROSMsg(*transformed_cloud, output);
        output.header.frame_id = "map";
        output.header.stamp = livox_lidar_stamp_;
        map_frame_pointcloud_pub->publish(output);

        comparePointClouds(transformed_cloud);

        //遍历map坐标系下点云A(sensor_msgs::msg::PointCloud2 output)的每一个点（用x，y）
        //首先获得这个点的x和y，然后找到对应点云B（sensor_msgs::msg::PointCloud2 taurus::Remove_pointcloud::pcd_map_）xy对应的点，
        //如果有，把z轴的数据作差，没有就继续比较下一个点，
        //结束后发布处理的点
        RCLCPP_INFO(this->get_logger(),"livox_lidar_pointcloud->points.size(): %ld",livox_lidar_pointcloud->points.size());
    }
    void Remove_pointcloud::comparePointClouds(pcl::PointCloud<pcl::PointXYZ>::Ptr cloud_b)
    {
        RCLCPP_INFO(this->get_logger(),"comparePointClouds");
        pcl::PointCloud<pcl::PointXYZ>::Ptr result_cloud(new pcl::PointCloud<pcl::PointXYZ>);

        for (const auto& cloud_b : cloud_b->points)
        {
            std::vector<int> pointIdxNKNSearch(1);
            std::vector<float> pointNKNSquaredDistance(1);

            if (kdTree.nearestKSearch(cloud_b, 1, pointIdxNKNSearch, pointNKNSquaredDistance) > 0)
            {
            float z_diff = map_cloud_->points[pointIdxNKNSearch[0]].z - cloud_b.z;
            // 如果z轴差值大于或等于0.3米，则保存这个点
            if (std::abs(z_diff) >= 0.5)
            {
                result_cloud->points.push_back(pcl::PointXYZ(cloud_b.x, cloud_b.y, z_diff));
            }
            }
        }

        // 转换回PointCloud2并发布
        sensor_msgs::msg::PointCloud2 output;
        pcl::toROSMsg(*result_cloud, output);
        output.header.frame_id = "map";
        output.header.stamp = livox_lidar_stamp_;
        processed_point_cloud_pub_->publish(output);
    }

} // namespace taurus
#include "rclcpp_components/register_node_macro.hpp"
RCLCPP_COMPONENTS_REGISTER_NODE(taurus::Remove_pointcloud);